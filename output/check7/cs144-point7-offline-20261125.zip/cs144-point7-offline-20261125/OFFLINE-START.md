# Point 7 离线源码与端点程序

适用：Ubuntu 24.04 x86_64，两位同学已确认 GCC 13.3、CMake 3.28。
包含完整编译所需源码，以及本项目已验证的 tcp_eth_udp_sanitized 程序。
预编译程序仍使用你们已有的 Linux 运行库；若提示缺库或架构不匹配，请保留原始错误。

## 解压位置

将 ZIP 发给两位同学，并复制到各自 Ubuntu。
在 Ubuntu 打开 ZIP，将里面的 cs144-point7-offline-20261125 文件夹提取到主目录 Home。
不要在 Windows 共享文件夹里直接运行，聊天文件发布需要 Linux 文件系统的硬链接支持。
Windows 上的 UDP 转发 READY 窗口继续运行。

## 进入目录（两人都执行）

```bash
cd "$HOME/cs144-point7-offline-20261125"
chmod +x bin/tcp_eth_udp_sanitized scripts/*.sh tests/*.sh
```

## B 先启动服务端

```bash
python3 tools/check7/chat.py --name B --downloads build/three-host-B -- ./bin/tcp_eth_udp_sanitized server 2050 50.0.0.1 50.9.8.7:80
```

保持程序运行，显示监听或 READY 后，再让 A 启动。

## A 后启动客户端

```bash
python3 tools/check7/chat.py --name A --downloads build/three-host-A -- ./bin/tcp_eth_udp_sanitized client 2080 192.168.226.1:12080 80.0.0.1 80.6.5.4 50.9.8.7:80
```

成功连接后两人各输入一句普通文字，确认对方出现 CHAT。
不要再次运行 UDP 探测占用 2050/2080 端口。

## 1 MiB 文件验证

保持聊天窗口开启，双方另开 Ubuntu 终端，在本文件夹执行：

```bash
cd "$HOME/cs144-point7-offline-20261125"
python3 -c 'import hashlib,pathlib; pathlib.Path("build/test-1MiB.bin").write_bytes(hashlib.shake_256(b"CS144 peer test").digest(1048576))'
sha256sum build/test-1MiB.bin
```

再回到各自聊天窗口输入：

```text
/send build/test-1MiB.bin
```

双方均要发送并核对对方 FILE VERIFIED 的字节数、SHA-256。
FILE SENT 只说明本地写出了字节，不能代替接收成功。
全部完成后，双方各输入 /quit，等待 receipts.json 写入。
请把聊天结果和两个方向的验证结果交给当前协助实验的助手记录。

## 从源码编译（可选）

```bash
cmake -S . -B build/wsl -DSANITIZED_APPS=True
CMAKE_BUILD_PARALLEL_LEVEL=2 cmake --build build/wsl --target tcp_eth_udp_sanitized
```

之后也可以把上面的 ./bin/tcp_eth_udp_sanitized 换成 ./build/wsl/apps/tcp_eth_udp_sanitized。
本包的源码取自 SOURCE_COMMIT.txt 标明的提交，未混入其他本地改动或 Git 凭据。
SHA256SUMS.json 列出包内内容的哈希。
